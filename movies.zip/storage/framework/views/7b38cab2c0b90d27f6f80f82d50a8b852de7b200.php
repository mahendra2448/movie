<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Movie - The Cinema</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" crossorigin="anonymous">
</head>

<body>
    
    <div class="m-5 py-4">
        <h1 class="text-center pb-2">Movie - The Cinema</h1>

        <div class="row rows-cols-2">
            <?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col">
                    <div class="card shadow" style="width: 25rem;">
                        <img src="<?php echo e($movie['cover']); ?>" class="card-img-top" alt="<?php echo e($movie['title']); ?>">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($movie['title']); ?></h5>
                            <p class="card-text"><?php echo $movie['synopsis']; ?></p>

                            <br>
                            Starring: 
                            <?php $__currentLoopData = $movie['actors']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $act): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($act); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <br>
                            Director: 
                            <?php $__currentLoopData = $movie['director']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($dic); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <br>
                            Genre: <?php echo e($movie['genre']); ?> <br>
                            Age: <?php echo e($movie['age']); ?> <br>
                            Duration: <?php echo e($movie['duration']); ?>

                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>






    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html><?php /**PATH D:\data\webs\kotadi\movies\resources\views/index.blade.php ENDPATH**/ ?>