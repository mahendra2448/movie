-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.6.4-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             11.3.0.6295
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Dumping data for table movie.failed_jobs: ~0 rows (approximately)
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;

-- Dumping data for table movie.migrations: ~9 rows (approximately)
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
	(1, '2014_10_12_000000_create_users_table', 1),
	(2, '2014_10_12_100000_create_password_resets_table', 1),
	(3, '2019_08_19_000000_create_failed_jobs_table', 1),
	(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
	(5, '2021_03_30_203216_create_products_table', 1),
	(6, '2021_10_06_091703_create_movies_table', 2),
	(7, '2021_10_06_092428_create_theatres_table', 2),
	(8, '2021_10_06_094445_create_people_table', 2),
	(9, '2021_10_06_114015_create_table_person', 3);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;

-- Dumping data for table movie.movies: ~5 rows (approximately)
/*!40000 ALTER TABLE `movies` DISABLE KEYS */;
INSERT INTO `movies` (`id`, `movie_id`, `title`, `synopsis`, `duration`, `genre`, `age`, `cover`, `created_at`, `updated_at`) VALUES
	(1, 'MOV01', 'JUNGLE CRUISE', 'Frank (Dwayne Johnson) adalah kapten kapal yang berkharisma. Ia bertemu dengan Lily (Emily Blunt), seorang penjelajah yang berambisi menemukan kebenaran mengenai pohon ajaib yang memiliki kekuatan penyembuh. Petualangan keduanya tidaklah mudah, karena mereka akan menghadapi beragam tantangan yang mengancam nyawa. Pohon ajaib harus ditemukan, karena jika jatuh ke tangan yang salah akan ada bencana yang besar.', '127 Minutes', 'ADVENTURE', '13+', 'https://cdn.cgv.id/uploads/movie/compressed/21012500.jpg', NULL, NULL),
	(2, 'MOV02', 'BLACKPINK: THE MOVIE', 'Grup wanita yang dicintai oleh dunia, BLACKPINK merayakan ulang tahun ke-5 debut mereka dengan merilis BLACKPINK THE MOVIE, ini juga merupakan hadiah spesial untuk BLINKs—fandom tercinta BLACKPINK— untuk mengingat kembali kenangan lama dan menikmati penampilan penuh gairah dalam semangat pesta. BLACKPINK—yang terdiri dari JISOO, JENNIE, ROSÉ, dan LISA—telah berkembang pesat sejak mereka pertama kali muncul di dunia pada 8 Agustus 2016, bersama dengan fandomnya BLINK. Sesibuk apa pun selama lima tahun terakhir, semua kenangan, kesenangan di atas panggung, dan momen bersinar mereka telah dikemas -seperti hadiah untuk semua penggemar- di BLACKPINK THE MOVIE. Film ini terdiri dari beragam urutan yang berfokus pada setiap anggota BLACKPINK, beberapa di antaranya adalah: The Room of Memories; segmen berbagi kenangan lima tahun sejak debut BLACKPINK, Beauty; rekaman menarik dari keempat anggota dengan karakteristik mereka yang berbeda, Wawancara Eksklusif; sebuah pesan untuk para penggemar. Selain itu, panggung khas BLACKPINK yang melampaui kebangsaan dan gender yang memikat dunia dengan penampilan luar biasa memenuhi layar dengan kehadiran yang maksimal. THE SHOW (2021), IN YOUR AREA (2018), dan selusin lagu hit lainnya dari BLACKPINK akan ditampilkan di layar untuk memberikan pengalaman menyentuh kepada para penggemar seolah-olah mereka benar-benar berada di acara fan meeting dan konser langsungnya.', '100 Minutes', 'MUSIC', '13+', 'https://cdn.cgv.id/uploads/movie/compressed/21012600.jpg', NULL, NULL),
	(3, 'MOV03', 'MALIGNANT', 'Madison dilumpuhkan oleh penglihatan mengejutkan tentang pembunuhan yang mengerikan, dan siksaannya semakin memburuk ketika dia menyadari bahwa mimpi-mimpi ini sebenarnya adalah kenyataan yang menakutkan. <br><br>Madison is paralyzed by shocking visions of grisly murders, and her torment worsens as she discovers that these waking dreams are in fact terrifying realities', '111 Minutes', 'HORROR', '17+', 'https://cdn.cgv.id/uploads/movie/compressed/21011800.jpg', NULL, NULL),
	(4, 'MOV04', 'NO TIME TO DIE', 'Dalam No Time To Die, Bond sudah pensiun dan menikmati hidup tenang di Jamaika. Ketenangannya hanya sebentar tatkala teman lamanya Felix Leiter dari CIA datang untuk meminta bantuan. Sebuah misi untuk menyelamatkan ilmuwan yang diculik ternyata jauh lebih berbahaya dari yang diperkirakan, membawa Bond menyusuri jejak seorang penjahat misterius yang dipersenjatai dengan teknologi baru yang berbahaya.', '163 Minutes', 'ACTION', '13+', 'https://cdn.cgv.id/uploads/movie/compressed/21012300.jpg', NULL, NULL),
	(5, 'MOV05', 'SHANG-CHI AND THE LEGEND OF THE TEN RINGS', 'Shang-Chi (Simu Liu) harus menghadapi masa lalunya sebelum ia memilih untuk meninggalkan dan bergabung ke dalam sebuah organisasi bernama Ten Rings. <br><br>Shang-Chi, the master of unarmed weaponry-based Kung Fu, is forced to confront his past after being drawn into the Ten Rings organization.', '132 Minutes', 'ACTION', 'SU', 'https://cdn.cgv.id/uploads/movie/compressed/21011700.jpg', NULL, NULL);
/*!40000 ALTER TABLE `movies` ENABLE KEYS */;

-- Dumping data for table movie.password_resets: ~0 rows (approximately)
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;

-- Dumping data for table movie.people: ~19 rows (approximately)
/*!40000 ALTER TABLE `people` DISABLE KEYS */;
INSERT INTO `people` (`id`, `pname`, `director`, `actors`, `created_at`, `updated_at`) VALUES
	(1, 'Jaume Collet-Serra', 'MOV01', '', NULL, NULL),
	(2, 'Dwayne Johnson', '', 'MOV01', NULL, NULL),
	(3, 'Emily Blunt', '', 'MOV01', NULL, NULL),
	(4, 'Su Yee Jung', 'MOV02', '', NULL, NULL),
	(6, 'Oh Yoon-Dong', 'MOV02', '', NULL, NULL),
	(7, 'Jennie Kim', '', 'MOV02', NULL, NULL),
	(8, 'Rosé', '', 'MOV02', NULL, NULL),
	(9, 'Jisoo Kim', '', 'MOV02', NULL, NULL),
	(10, 'Lalisa Manoban', '', 'MOV02', NULL, NULL),
	(11, 'James Wan', 'MOV03', '', NULL, NULL),
	(12, 'Annabelle Wallis', '', 'MOV03', NULL, NULL),
	(13, 'Maddie Hasson', '', 'MOV03', NULL, NULL),
	(14, 'Cary Joji Fukunaga', 'MOV04', '', NULL, NULL),
	(15, 'Daniel Craig', '', 'MOV04', NULL, NULL),
	(16, 'Lea Seydoux', '', 'MOV04', NULL, NULL),
	(17, 'Rami Malek', '', 'MOV04', NULL, NULL),
	(18, 'Destin Daniel Cretton', 'MOV05', '', NULL, NULL),
	(19, 'Simu Liu', '', 'MOV05', NULL, NULL),
	(20, 'Awkwafina', '', 'MOV05', NULL, NULL);
/*!40000 ALTER TABLE `people` ENABLE KEYS */;

-- Dumping data for table movie.personal_access_tokens: ~1 rows (approximately)
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
INSERT INTO `personal_access_tokens` (`id`, `tokenable_type`, `tokenable_id`, `name`, `token`, `abilities`, `last_used_at`, `created_at`, `updated_at`) VALUES
	(5, 'App\\Models\\User', 1, 'myapptoken', '0f5253f52ecd9bb1656fb7301859128a53bf9ec39861d0b041d4ae5ee5b84c96', '["*"]', '2021-10-06 09:13:07', '2021-10-06 09:12:47', '2021-10-06 09:13:07'),
	(6, 'App\\Models\\User', 1, 'myapptoken', '55f6df1446778fe9a974a0d2b9ca68c47e74a41a3eab3a0ec9d5fd7ae8ababa6', '["*"]', NULL, '2021-10-06 12:39:03', '2021-10-06 12:39:03');
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;

-- Dumping data for table movie.products: ~2 rows (approximately)
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` (`id`, `name`, `slug`, `description`, `price`, `created_at`, `updated_at`) VALUES
	(1, 'Xiaomi 10', 'xiaomi-10', 'This is product Xiaomi 10', 499.99, '2021-10-06 08:50:12', '2021-10-06 08:50:12'),
	(2, 'Xiaomi 11', 'xiaomi-11', 'This is product Xiaomi 11', 499.99, '2021-10-06 09:13:07', '2021-10-06 09:13:07');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;

-- Dumping data for table movie.theatres: ~12 rows (approximately)
/*!40000 ALTER TABLE `theatres` DISABLE KEYS */;
INSERT INTO `theatres` (`id`, `theatre_id`, `theatre_name`, `movie`, `tanggal`, `play_time`) VALUES
	(1, 'CIN01', 'Grand Indonesia', 'MOV01', '06 Okt 2021', '12.30'),
	(2, 'CIN01', 'Grand Indonesia', 'MOV01', '06 Okt 2021', '17.00'),
	(3, 'CIN01', 'Grand Indonesia', 'MOV01', '07 OKt 2021', '13.30'),
	(4, 'CIN02', 'Grand Indonesia', 'MOV02', '06 Okt 2021', '13.30'),
	(5, 'CIN02', 'Grand Indonesia', 'MOV02', '06 Okt 2021', '19.00'),
	(6, 'CIN02', 'Grand Indonesia', 'MOV03', '07 OKt 2021', '11.30'),
	(7, 'CIN03', 'Grand Indonesia', 'MOV04', '06 Okt 2021', '13.30'),
	(8, 'CIN03', 'Grand Indonesia', 'MOV04', '06 Okt 2021', '18.00'),
	(9, 'CIN04', 'Grand Indonesia', 'MOV05', '07 OKt 2021', '11.30'),
	(10, 'CIN04', 'Grand Indonesia', 'MOV05', '06 Okt 2021', '13.30'),
	(11, 'CIN04', 'Grand Indonesia', 'MOV05', '06 Okt 2021', '15.00'),
	(12, 'CIN04', 'Grand Indonesia', 'MOV05', '07 OKt 2021', '12.30');
/*!40000 ALTER TABLE `theatres` ENABLE KEYS */;

-- Dumping data for table movie.users: ~0 rows (approximately)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
	(1, 'Mahendra', 'mahendra@d-voc.id', NULL, '$2y$10$nMr/Yg5ReXg1vQOny9n.2e8IULGIfnV91fChZiZ.ApMaQnk2XdBUK', NULL, '2021-10-06 08:47:24', '2021-10-06 08:47:24');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
